'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { NAVIGATION, COMPANY } from '@/lib/constants';

// Type guard to check if a nav item has children
function hasChildren(item: typeof NAVIGATION.public[number]): item is typeof NAVIGATION.public[number] & { children: typeof NAVIGATION.public } {
  return 'children' in item && Array.isArray(item.children);
}
import { cn } from '@/lib/utils';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isActive = (href: string) => pathname === href;

  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-500',
        isScrolled
          ? 'bg-white/90 backdrop-blur-xl shadow-premium'
          : 'bg-transparent'
      )}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex items-center gap-2"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#2563EB] to-[#06B6D4]">
                <span className="text-lg font-bold text-white">F</span>
              </div>
              <span className={cn(
                'text-xl font-semibold tracking-tight transition-colors',
                isScrolled ? 'text-[#0F172A]' : 'text-[#0F172A]'
              )}>
                {COMPANY.name}
              </span>
            </motion.div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {NAVIGATION.public.map((item) => (
              <div
                key={item.label}
                className="relative"
                onMouseEnter={() => hasChildren(item) && setActiveDropdown(item.label)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  href={item.href}
                  className={cn(
                    'flex items-center gap-1 px-4 py-2 text-sm font-medium rounded-lg transition-all duration-300',
                    isActive(item.href)
                      ? 'text-[#2563EB] bg-[#2563EB]/5'
                      : isScrolled
                        ? 'text-[#64748B] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
                        : 'text-[#64748B] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
                  )}
                >
                  {item.label}
                  {hasChildren(item) && (
                    <ChevronDown className={cn(
                      'h-4 w-4 transition-transform duration-300',
                      activeDropdown === item.label && 'rotate-180'
                    )} />
                  )}
                </Link>

                {/* Dropdown Menu */}
                <AnimatePresence>
                  {hasChildren(item) && activeDropdown === item.label && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      transition={{ duration: 0.2 }}
                      className="absolute top-full left-0 mt-2 w-64 bg-white rounded-xl shadow-premium-hover border border-[#E2E8F0] overflow-hidden"
                    >
                      <div className="p-2">
                        {item.children!.map((child, idx) => (
                          <Link
                            key={child.label}
                            href={child.href}
                            className={cn(
                              'flex items-center px-4 py-3 text-sm rounded-lg transition-all duration-200',
                              isActive(child.href)
                                ? 'bg-[#2563EB]/5 text-[#2563EB]'
                                : 'text-[#64748B] hover:bg-[#F1F5F9] hover:text-[#0F172A]'
                            )}
                          >
                            {child.label}
                          </Link>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden lg:flex items-center gap-4">
            <Link href="/contact">
              <Button
                className="btn-gradient font-medium px-6 py-2.5 rounded-xl shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30"
              >
                Get Started
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 text-[#0F172A] rounded-lg hover:bg-[#F1F5F9] transition-colors"
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="lg:hidden bg-white border-t border-[#E2E8F0]"
          >
            <div className="px-4 py-6 space-y-2">
              {NAVIGATION.public.map((item) => (
                <div key={item.label}>
                  <Link
                    href={item.href}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={cn(
                      'flex items-center px-4 py-3 text-base font-medium rounded-lg transition-all',
                      isActive(item.href)
                        ? 'bg-[#2563EB]/5 text-[#2563EB]'
                        : 'text-[#64748B] hover:bg-[#F1F5F9] hover:text-[#0F172A]'
                    )}
                  >
                    {item.label}
                  </Link>
                  {hasChildren(item) && (
                    <div className="ml-4 mt-2 space-y-1 border-l-2 border-[#E2E8F0] pl-4">
                      {item.children.map((child) => (
                        <Link
                          key={child.label}
                          href={child.href}
                          onClick={() => setIsMobileMenuOpen(false)}
                          className={cn(
                            'flex items-center px-4 py-2 text-sm rounded-lg transition-all',
                            isActive(child.href)
                              ? 'bg-[#2563EB]/5 text-[#2563EB]'
                              : 'text-[#64748B] hover:bg-[#F1F5F9] hover:text-[#0F172A]'
                          )}
                        >
                          {child.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <div className="pt-4">
                <Link href="/contact" onClick={() => setIsMobileMenuOpen(false)}>
                  <Button className="w-full btn-gradient font-medium py-3 rounded-xl">
                    Get Started
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
