'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin } from 'lucide-react';
import { COMPANY, NAVIGATION } from '@/lib/constants';
import { Separator } from '@/components/ui/separator';

export function Footer() {
  const currentYear = new Date().getFullYear();

  // Get service links from navigation
  const serviceLinks = NAVIGATION.public.find(item => item.label === 'Services')?.children || [];

  return (
    <footer className="bg-[#0B1220] text-white">
      {/* Main Footer */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#2563EB] to-[#06B6D4]">
                <span className="text-lg font-bold text-white">F</span>
              </div>
              <span className="text-xl font-semibold tracking-tight">
                {COMPANY.name}
              </span>
            </Link>
            <p className="text-[#94A3B8] text-sm leading-relaxed mb-6">
              Premium outsourced accounting and finance support for CPA firms, tax practices, and financial businesses. Your trusted partner for growth.
            </p>
            <div className="flex items-center gap-4">
              <a
                href={COMPANY.social.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/5 text-[#94A3B8] hover:bg-[#2563EB] hover:text-white transition-all duration-300"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                </svg>
              </a>
              <a
                href={COMPANY.social.twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/5 text-[#94A3B8] hover:bg-[#06B6D4] hover:text-white transition-all duration-300"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Services Column */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white mb-6">
              Services
            </h3>
            <ul className="space-y-3">
              {serviceLinks.slice(0, 6).map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-[#94A3B8] hover:text-white text-sm transition-colors duration-300"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Column */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white mb-6">
              Company
            </h3>
            <ul className="space-y-3">
              <li>
                <Link href="/about" className="text-[#94A3B8] hover:text-white text-sm transition-colors duration-300">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/case-studies" className="text-[#94A3B8] hover:text-white text-sm transition-colors duration-300">
                  Case Studies
                </Link>
              </li>
              <li>
                <Link href="/careers" className="text-[#94A3B8] hover:text-white text-sm transition-colors duration-300">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-[#94A3B8] hover:text-white text-sm transition-colors duration-300">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-[#94A3B8] hover:text-white text-sm transition-colors duration-300">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/privacy-policy" className="text-[#94A3B8] hover:text-white text-sm transition-colors duration-300">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Column */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white mb-6">
              Contact
            </h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-[#2563EB] mt-0.5" />
                <a
                  href={`mailto:${COMPANY.email}`}
                  className="text-[#94A3B8] hover:text-white text-sm transition-colors duration-300"
                >
                  {COMPANY.email}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-[#2563EB] mt-0.5" />
                <a
                  href={`tel:${COMPANY.phone}`}
                  className="text-[#94A3B8] hover:text-white text-sm transition-colors duration-300"
                >
                  {COMPANY.phone}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-[#2563EB] mt-0.5" />
                <span className="text-[#94A3B8] text-sm">
                  {COMPANY.location}
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <Separator className="bg-white/10" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[#64748B] text-sm">
            &copy; {currentYear} {COMPANY.name}. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link href="/privacy-policy" className="text-[#64748B] hover:text-white text-sm transition-colors">
              Privacy
            </Link>
            <Link href="#" className="text-[#64748B] hover:text-white text-sm transition-colors">
              Terms
            </Link>
            <Link href="#" className="text-[#64748B] hover:text-white text-sm transition-colors">
              Cookies
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
