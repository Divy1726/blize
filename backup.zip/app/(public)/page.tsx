'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import Image from 'next/image';
import {
  ArrowRight,
  ArrowUpRight,
  CheckCircle,
  BarChart3,
  Shield,
  Clock,
  Users,
  Briefcase,
  Calculator,
  FileText,
  BookOpen,
  TrendingUp,
  Receipt,
  CreditCard,
  ClipboardCheck,
  Star,
  Calculator as CalculatorIcon,
  FileSpreadsheet,
  Building2,
  Leaf,
  Waves,
  Play,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  AnimatedSection,
  StaggerContainer,
  StaggerItem,
  AnimatedCounter,
} from '@/components/shared/AnimatedSection';
import {
  STATS,
  SERVICES,
  TESTIMONIALS,
  CASE_STUDIES,
  FAQS,
  SOFTWARE_LOGOS,
  COMPANY,
} from '@/lib/constants';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Card, CardContent } from '@/components/ui/card';

// Icon mapping
const iconMap: Record<string, React.ElementType> = {
  Calculator,
  TrendingUp,
  BookOpen,
  FileText,
  ClipboardCheck,
  Briefcase,
  CreditCard,
  Receipt,
  CalculatorIcon,
  FileSpreadsheet,
  Building2,
  Leaf,
  Waves,
};

// Service Icon Component
function ServiceIcon({ icon }: { icon: string }) {
  const IconComponent = iconMap[icon] || Calculator;
  return <IconComponent className="h-6 w-6" />;
}

// Hero Section
function HeroSection() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-32 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-400/10 rounded-full blur-3xl" />
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            <Badge className="mb-6 bg-blue-500/10 text-blue-600 border-blue-200 hover:bg-blue-500/20">
              Trusted by 100+ Accounting Firms
            </Badge>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#0F172A] leading-tight mb-6">
              Scale Your Firm With{' '}
              <span className="text-gradient">Premium</span>{' '}
              Outsourced Support
            </h1>
            <p className="text-lg text-[#64748B] leading-relaxed mb-8 max-w-xl">
              {COMPANY.description} We handle the numbers so you can focus on growing your practice and serving your clients.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/contact">
                <Button
                  size="lg"
                  className="btn-gradient font-medium px-8 py-6 rounded-xl shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30 text-base"
                >
                  Book a Consultation
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/services">
                <Button
                  variant="outline"
                  size="lg"
                  className="font-medium px-8 py-6 rounded-xl border-[#E2E8F0] hover:bg-[#F1F5F9] text-base"
                >
                  Explore Services
                </Button>
              </Link>
            </div>

            {/* Trust Indicators */}
            <div className="mt-12 flex items-center gap-6 text-sm text-[#64748B]">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-emerald-500" />
                <span>No long-term contracts</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-emerald-500" />
                <span>99.8% accuracy rate</span>
              </div>
            </div>
          </motion.div>

          {/* Right Visual */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="relative"
          >
            {/* Dashboard Preview */}
            <div className="relative bg-white rounded-2xl shadow-premium-hover border border-[#E2E8F0] p-6">
              <div className="flex items-center gap-2 mb-4 pb-4 border-b border-[#E2E8F0]">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-400" />
                  <div className="w-3 h-3 rounded-full bg-amber-400" />
                  <div className="w-3 h-3 rounded-full bg-emerald-400" />
                </div>
                <div className="ml-4 text-xs text-[#94A3B8]">Financial Dashboard</div>
              </div>
              
              {/* Dashboard Content */}
              <div className="grid grid-cols-2 gap-4">
                {/* Stats Cards */}
                <div className="col-span-2 grid grid-cols-3 gap-3">
                  <div className="bg-[#F8FAFC] rounded-xl p-3">
                    <div className="text-xs text-[#64748B] mb-1">Revenue</div>
                    <div className="text-lg font-semibold text-[#0F172A]">$2.4M</div>
                    <div className="text-xs text-emerald-500 flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" /> +12.5%
                    </div>
                  </div>
                  <div className="bg-[#F8FAFC] rounded-xl p-3">
                    <div className="text-xs text-[#64748B] mb-1">Expenses</div>
                    <div className="text-lg font-semibold text-[#0F172A]">$1.8M</div>
                    <div className="text-xs text-emerald-500 flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" /> -5.2%
                    </div>
                  </div>
                  <div className="bg-[#F8FAFC] rounded-xl p-3">
                    <div className="text-xs text-[#64748B] mb-1">Profit</div>
                    <div className="text-lg font-semibold text-[#0F172A]">$605K</div>
                    <div className="text-xs text-emerald-500 flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" /> +24.8%
                    </div>
                  </div>
                </div>

                {/* Chart Placeholder */}
                <div className="col-span-2 bg-[#F8FAFC] rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="text-xs font-medium text-[#0F172A]">Monthly Cash Flow</div>
                    <div className="flex gap-2">
                      <span className="text-xs text-[#64748B]">Income</span>
                      <span className="text-xs text-[#64748B]">Expenses</span>
                    </div>
                  </div>
                  <div className="flex items-end justify-between h-24 gap-2">
                    {[40, 65, 45, 80, 55, 70, 60, 85, 75, 90, 70, 95].map((height, i) => (
                      <div key={i} className="flex-1 flex flex-col gap-1">
                        <div
                          className="bg-blue-500 rounded-t"
                          style={{ height: `${height}%` }}
                        />
                        <div
                          className="bg-cyan-400 rounded-t"
                          style={{ height: `${height * 0.6}%` }}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Elements */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -top-4 -right-4 bg-white rounded-xl shadow-premium p-4 border border-[#E2E8F0]"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">
                  <CheckCircle className="h-5 w-5 text-emerald-500" />
                </div>
                <div>
                  <div className="text-sm font-medium text-[#0F172A]">Books Closed</div>
                  <div className="text-xs text-[#64748B]">Monthly reconciled</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
              className="absolute -bottom-4 -left-4 bg-white rounded-xl shadow-premium p-4 border border-[#E2E8F0]"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <Clock className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <div className="text-sm font-medium text-[#0F172A]">Time Saved</div>
                  <div className="text-xs text-[#64748B]">35 hrs/week</div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// Trusted Tools Section
function TrustedToolsSection() {
  return (
    <section className="py-12 border-y border-[#E2E8F0] bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <p className="text-center text-sm text-[#64748B] mb-8">
          Trusted tools and software we work with
        </p>
        <div className="flex flex-wrap justify-center items-center gap-8 lg:gap-16">
          {SOFTWARE_LOGOS.map((tool) => (
            <div
              key={tool.name}
              className="flex items-center gap-2 text-[#94A3B8] hover:text-[#64748B] transition-colors duration-300"
            >
              <ServiceIcon icon={tool.icon} />
              <span className="font-medium">{tool.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Why Choose Us Section
function WhyChooseUsSection() {
  const reasons = [
    {
      icon: Users,
      title: 'Experienced Team',
      description: 'CPAs and accounting professionals with an average of 10+ years of experience.',
    },
    {
      icon: Shield,
      title: 'Secure & Confidential',
      description: 'Bank-level security protocols and strict confidentiality agreements with all team members.',
    },
    {
      icon: Clock,
      title: 'Fast Turnaround',
      description: 'Average 24-48 hour response time with flexible scheduling for urgent needs.',
    },
    {
      icon: BarChart3,
      title: 'Scalable Solutions',
      description: 'Easily scale support up or down based on your seasonal needs and business growth.',
    },
    {
      icon: CheckCircle,
      title: 'Quality Assurance',
      description: 'Multi-layer review process ensures 99.8% accuracy in all deliverables.',
    },
    {
      icon: Briefcase,
      title: 'Industry Expertise',
      description: 'Deep knowledge across multiple industries including professional services, retail, and technology.',
    },
  ];

  return (
    <section className="py-20 lg:py-28 bg-[#F8FAFC]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="mb-4 bg-slate-100 text-slate-600 border-slate-200">
            Why Firms Choose Us
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#0F172A] mb-4">
            The Partner Your Firm Deserves
          </h2>
          <p className="text-lg text-[#64748B]">
            We combine expertise, technology, and a commitment to excellence to deliver results that exceed expectations.
          </p>
        </AnimatedSection>

        <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reasons.map((reason) => (
            <StaggerItem key={reason.title}>
              <Card className="group bg-white border-[#E2E8F0] hover:border-blue-200 hover:shadow-premium-hover transition-all duration-300 h-full">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500/10 to-cyan-500/10 flex items-center justify-center mb-4 group-hover:from-blue-500/20 group-hover:to-cyan-500/20 transition-colors">
                    <reason.icon className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-[#0F172A] mb-2">
                    {reason.title}
                  </h3>
                  <p className="text-[#64748B] text-sm leading-relaxed">
                    {reason.description}
                  </p>
                </CardContent>
              </Card>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}

// Services Section
function ServicesSection() {
  return (
    <section className="py-20 lg:py-28 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="mb-4 bg-blue-500/10 text-blue-600 border-blue-200">
            Our Services
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#0F172A] mb-4">
            Comprehensive Financial Support
          </h2>
          <p className="text-lg text-[#64748B]">
            From daily bookkeeping to strategic CFO advisory, we provide the full spectrum of accounting and financial services.
          </p>
        </AnimatedSection>

        <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SERVICES.map((service) => (
            <StaggerItem key={service.slug}>
              <Link href={`/services/${service.slug}`}>
                <Card className="group h-full bg-white border-[#E2E8F0] hover:border-blue-200 hover:shadow-premium-hover transition-all duration-300 cursor-pointer">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500/10 to-cyan-500/10 flex items-center justify-center mb-4 group-hover:from-blue-500/20 group-hover:to-cyan-500/20 transition-colors">
                      <ServiceIcon icon={service.icon} />
                    </div>
                    <h3 className="text-lg font-semibold text-[#0F172A] mb-2 group-hover:text-blue-600 transition-colors">
                      {service.shortTitle}
                    </h3>
                    <p className="text-[#64748B] text-sm leading-relaxed mb-4">
                      {service.shortDescription}
                    </p>
                    <div className="flex items-center text-blue-600 text-sm font-medium group-hover:gap-2 transition-all">
                      Learn more
                      <ArrowUpRight className="h-4 w-4 ml-1 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </StaggerItem>
          ))}
        </StaggerContainer>

        <div className="text-center mt-12">
          <Link href="/services">
            <Button
              variant="outline"
              size="lg"
              className="font-medium px-8 py-6 rounded-xl border-[#E2E8F0] hover:bg-[#F1F5F9]"
            >
              View All Services
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}

// How We Work Section
function HowWeWorkSection() {
  const steps = [
    {
      number: '01',
      title: 'Discovery',
      description: 'We start with a thorough consultation to understand your specific needs, challenges, and goals.',
    },
    {
      number: '02',
      title: 'Transition',
      description: 'Seamless onboarding with secure system access setup and process documentation.',
    },
    {
      number: '03',
      title: 'Execution',
      description: 'Our team begins delivering services with regular communication and quality checkpoints.',
    },
    {
      number: '04',
      title: 'Review',
      description: 'Monthly business reviews to assess performance, address concerns, and optimize processes.',
    },
    {
      number: '05',
      title: 'Optimization',
      description: 'Continuous improvement based on your feedback and evolving business needs.',
    },
  ];

  return (
    <section className="py-20 lg:py-28 bg-[#0B1220] text-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="mb-4 bg-white/10 text-white border-white/20">
            How We Work
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
            A Proven Process for Success
          </h2>
          <p className="text-lg text-[#94A3B8]">
            Our streamlined approach ensures a smooth partnership from day one, with clear communication and measurable results.
          </p>
        </AnimatedSection>

        <div className="grid lg:grid-cols-5 gap-8">
          {steps.map((step, index) => (
            <AnimatedSection key={step.number} delay={index * 0.1} className="relative">
              {/* Connector line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-blue-500/50 to-transparent" />
              )}
              
              <div className="text-center lg:text-left">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400 text-white font-bold text-xl mb-4">
                  {step.number}
                </div>
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-[#94A3B8] text-sm leading-relaxed">
                  {step.description}
                </p>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

// Who We Help Section
function WhoWeHelpSection() {
  const clients = [
    {
      title: 'CPA Firms',
      description: 'Overflow support, seasonal staffing, and specialized services.',
      icon: Calculator,
    },
    {
      title: 'Tax Practices',
      description: 'Year-round bookkeeping and tax preparation assistance.',
      icon: FileText,
    },
    {
      title: 'Bookkeeping Firms',
      description: 'Scalable team extension for growing client bases.',
      icon: BookOpen,
    },
    {
      title: 'Accounting Agencies',
      description: 'Full-service accounting and advisory support.',
      icon: Briefcase,
    },
    {
      title: 'Financial Consultants',
      description: 'Back-office support to maximize client-facing time.',
      icon: TrendingUp,
    },
  ];

  return (
    <section className="py-20 lg:py-28 bg-[#F8FAFC]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="mb-4 bg-slate-100 text-slate-600 border-slate-200">
            Who We Help
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#0F172A] mb-4">
            Serving Financial Professionals
          </h2>
          <p className="text-lg text-[#64748B]">
            We partner with a diverse range of accounting and financial services firms.
          </p>
        </AnimatedSection>

        <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
          {clients.map((client) => (
            <StaggerItem key={client.title}>
              <Card className="group h-full bg-white border-[#E2E8F0] hover:border-blue-200 hover:shadow-premium-hover transition-all duration-300">
                <CardContent className="p-6 text-center">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500/10 to-cyan-500/10 flex items-center justify-center mx-auto mb-4 group-hover:from-blue-500/20 group-hover:to-cyan-500/20 transition-colors">
                    <client.icon className="h-7 w-7 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-[#0F172A] mb-2">
                    {client.title}
                  </h3>
                  <p className="text-[#64748B] text-sm leading-relaxed">
                    {client.description}
                  </p>
                </CardContent>
              </Card>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}

// Stats Section
function StatsSection() {
  return (
    <section className="py-20 lg:py-28 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <StaggerContainer className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {STATS.map((stat) => (
            <StaggerItem key={stat.label}>
              <div className="text-center p-6">
                <div className="text-4xl sm:text-5xl font-bold text-gradient mb-2">
                  <AnimatedCounter value={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-lg font-semibold text-[#0F172A] mb-1">{stat.label}</div>
                <div className="text-sm text-[#64748B]">{stat.description}</div>
              </div>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}

// Trust/Security Section
function TrustSection() {
  return (
    <section className="py-20 lg:py-28 bg-[#F8FAFC]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <AnimatedSection>
            <Badge className="mb-4 bg-slate-100 text-slate-600 border-slate-200">
              Security & Trust
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#0F172A] mb-6">
              Your Data Security Is Our Priority
            </h2>
            <p className="text-lg text-[#64748B] mb-8">
              We understand that your financial data is sensitive. That&apos;s why we&apos;ve implemented comprehensive security measures to protect your information at every step.
            </p>
            
            <div className="space-y-4">
              {[
                'Bank-level 256-bit encryption for all data transfers',
                'SOC 2 Type II certified data centers',
                'Multi-factor authentication for all system access',
                'Strict NDAs and confidentiality agreements',
                'Regular security audits and penetration testing',
                'Role-based access controls and activity monitoring',
              ].map((item) => (
                <div key={item} className="flex items-start gap-3">
                  <Shield className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span className="text-[#64748B]">{item}</span>
                </div>
              ))}
            </div>
          </AnimatedSection>

          <AnimatedSection direction="right" className="relative">
            <div className="bg-white rounded-2xl shadow-premium p-8 border border-[#E2E8F0]">
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center p-4 bg-[#F8FAFC] rounded-xl">
                  <div className="text-3xl font-bold text-[#0F172A] mb-1">99.9%</div>
                  <div className="text-sm text-[#64748B]">Uptime Guarantee</div>
                </div>
                <div className="text-center p-4 bg-[#F8FAFC] rounded-xl">
                  <div className="text-3xl font-bold text-[#0F172A] mb-1">256-bit</div>
                  <div className="text-sm text-[#64748B]">Encryption</div>
                </div>
                <div className="text-center p-4 bg-[#F8FAFC] rounded-xl">
                  <div className="text-3xl font-bold text-[#0F172A] mb-1">SOC 2</div>
                  <div className="text-sm text-[#64748B]">Type II Certified</div>
                </div>
                <div className="text-center p-4 bg-[#F8FAFC] rounded-xl">
                  <div className="text-3xl font-bold text-[#0F172A] mb-1">GDPR</div>
                  <div className="text-sm text-[#64748B]">Compliant</div>
                </div>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  );
}

// Testimonials Section
function TestimonialsSection() {
  return (
    <section className="py-20 lg:py-28 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="mb-4 bg-blue-500/10 text-blue-600 border-blue-200">
            Testimonials
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#0F172A] mb-4">
            Trusted by Industry Leaders
          </h2>
          <p className="text-lg text-[#64748B]">
            See what our clients have to say about working with Finova Partners.
          </p>
        </AnimatedSection>

        <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {TESTIMONIALS.map((testimonial) => (
            <StaggerItem key={testimonial.id}>
              <Card className="h-full bg-white border-[#E2E8F0] hover:shadow-premium-hover transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <p className="text-[#64748B] text-sm leading-relaxed mb-6">
                    &ldquo;{testimonial.content}&rdquo;
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center">
                      <span className="text-sm font-semibold text-blue-600">
                        {testimonial.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#0F172A]">{testimonial.name}</div>
                      <div className="text-xs text-[#64748B]">
                        {testimonial.role}, {testimonial.company}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}

// Case Studies Section
function CaseStudiesSection() {
  return (
    <section className="py-20 lg:py-28 bg-[#0B1220] text-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-16">
          <div>
            <Badge className="mb-4 bg-white/10 text-white border-white/20">
              Case Studies
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">
              Real Results for Real Clients
            </h2>
          </div>
          <Link href="/case-studies">
            <Button
              variant="outline"
              size="lg"
              className="font-medium px-6 py-5 rounded-xl border-white/20 text-white hover:bg-white/10"
            >
              View All Cases
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </AnimatedSection>

        <StaggerContainer className="grid md:grid-cols-3 gap-8">
          {CASE_STUDIES.map((study) => (
            <StaggerItem key={study.slug}>
              <Link href={`/case-studies#${study.slug}`}>
                <Card className="group h-full bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20 transition-all duration-300 cursor-pointer">
                  <CardContent className="p-6">
                    <div className="text-xs text-blue-400 mb-2">{study.industry}</div>
                    <h3 className="text-xl font-semibold mb-4 group-hover:text-blue-400 transition-colors">
                      {study.title}
                    </h3>
                    <p className="text-[#94A3B8] text-sm mb-6 line-clamp-3">
                      {study.challenge}
                    </p>
                    <div className="space-y-2">
                      {study.results.slice(0, 2).map((result, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm">
                          <CheckCircle className="h-4 w-4 text-emerald-400 flex-shrink-0" />
                          <span className="text-[#E2E8F0]">{result}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}

// FAQ Preview Section
function FAQPreviewSection() {
  const previewFaqs = FAQS.slice(0, 4);

  return (
    <section className="py-20 lg:py-28 bg-[#F8FAFC]">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection className="text-center mb-12">
          <Badge className="mb-4 bg-slate-100 text-slate-600 border-slate-200">
            FAQ
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#0F172A] mb-4">
            Common Questions
          </h2>
          <p className="text-lg text-[#64748B]">
            Everything you need to know about working with us.
          </p>
        </AnimatedSection>

        <AnimatedSection delay={0.2}>
          <Accordion type="single" collapsible className="w-full">
            {previewFaqs.map((faq) => (
              <AccordionItem key={faq.id} value={faq.id} className="bg-white border border-[#E2E8F0] rounded-xl mb-4 px-6 data-[state=open]:border-blue-200">
                <AccordionTrigger className="text-left text-[#0F172A] font-medium hover:no-underline py-4">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-[#64748B] pb-4">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </AnimatedSection>

        <div className="text-center mt-8">
          <Link href="/faq">
            <Button
              variant="outline"
              className="font-medium px-6 py-5 rounded-xl border-[#E2E8F0] hover:bg-white"
            >
              View All FAQs
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}

// Final CTA Section
function FinalCTASection() {
  return (
    <section className="py-20 lg:py-28 bg-white">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <div className="relative overflow-hidden bg-gradient-to-br from-[#0B1220] to-[#1E293B] rounded-3xl p-8 sm:p-12 lg:p-16 text-center">
            {/* Background decoration */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-cyan-500/20 rounded-full blur-3xl" />
            
            <div className="relative z-10">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white mb-6">
                Ready to Scale Your Practice?
              </h2>
              <p className="text-lg text-[#94A3B8] mb-8 max-w-2xl mx-auto">
                Join 100+ accounting firms that trust Finova Partners to handle their financial operations. Get started with a free consultation.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/contact">
                  <Button
                    size="lg"
                    className="bg-white text-[#0F172A] hover:bg-[#F1F5F9] font-medium px-8 py-6 rounded-xl text-base"
                  >
                    Book a Consultation
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/contact?type=proposal">
                  <Button
                    variant="outline"
                    size="lg"
                    className="border-white/30 text-white hover:bg-white/10 font-medium px-8 py-6 rounded-xl text-base"
                  >
                    Get a Proposal
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

// Main Page Component
export default function HomePage() {
  return (
    <>
      <HeroSection />
      <TrustedToolsSection />
      <WhyChooseUsSection />
      <ServicesSection />
      <HowWeWorkSection />
      <WhoWeHelpSection />
      <StatsSection />
      <TrustSection />
      <TestimonialsSection />
      <CaseStudiesSection />
      <FAQPreviewSection />
      <FinalCTASection />
    </>
  );
}
